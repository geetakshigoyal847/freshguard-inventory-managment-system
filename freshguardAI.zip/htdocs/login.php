<?php
session_start();

include 'includes/db.php';

if(isset($_POST['login'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email'";

    $result = mysqli_query($conn,$query);

    if(mysqli_num_rows($result) > 0){

        $user = mysqli_fetch_assoc($result);

        if($password == $user['password']){

            $_SESSION['email'] = $email;
            $_SESSION['role'] = $user['role'];

            header("Location: expiry_alerts.php");
            exit();

        } else {
            echo "Incorrect password";
        }

    } else {
        echo "Account not found";
    }

}

?>


<!DOCTYPE html>
<html>

<head>
<title>FreshGuard Login</title>
<link rel="stylesheet" href="style.css">
</head>


<body>

<h2>FreshGuard Supermarket</h2>

<p>Authorized staff access only</p>


<form method="POST">

<label>Email address</label>
<br>
<input type="email" name="email" required>

<br><br>

<label>Password</label>
<br>
<input type="password" name="password" required>

<br><br>

<button name="login">Login</button>

</form>


<br>

<a href="register.php">Create an account</a>


</body>

</html>
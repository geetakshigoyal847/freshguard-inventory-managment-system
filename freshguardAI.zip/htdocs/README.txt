FreshGuard Supermarket XAMPP PHP v5 - Reports Upgrade

Main upgrades:
- Rebuilt Reports page.
- Daily report generation button.
- Manual PDF export using browser print/save as PDF.
- Report recipients page for manager and staff emails.
- Report history table.
- Improved report graphs:
  Waste risk distribution
  Predicted demand by category
- Report delivery workflow:
  XAMPP demo stores delivery history in database.
  Real production version would connect to SMTP + cron job.
- Existing staff permissions, 50 products, one FreshGuard Supermarket store, and XGBoost-style forecasting remain included.

Install:
1. Copy freshguard_supermarket_xampp_v5_reports to C:/xampp/htdocs/
2. Start Apache and MySQL in XAMPP.
3. Open http://localhost/phpmyadmin
4. Import database.sql
5. Open http://localhost/freshguard_supermarket_xampp_v5_reports/

Admin login:
admin@freshguard.com
admin123

Manager login:
manager@freshguard.com
manager123

Staff login:
staff@freshguard.com
staff123

Viewer login:
viewer@freshguard.com
viewer123

Login page does not show credentials.